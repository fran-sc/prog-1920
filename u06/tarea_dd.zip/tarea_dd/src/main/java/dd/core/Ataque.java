package dd.core;

public interface Ataque {
    int lanzaAtaque(Personaje enemigo);
}
